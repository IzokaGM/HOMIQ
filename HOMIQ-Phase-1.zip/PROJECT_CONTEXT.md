# HOMIQ Project Context

Last context reset: 31 August 2026

This file is the main source of truth for HOMIQ. Any AI, developer, or new ChatGPT account continuing this project must read this file and `docs/FLOWCHART.md` before proposing code changes.

## 1. Resume protocol

When continuing HOMIQ in a new conversation or account:

1. Read this entire file.
2. Read `docs/FLOWCHART.md`.
3. Inspect the live repository before changing code.
4. Check the current phase and completed checklist.
5. Do not redesign locked product decisions unless the owner explicitly asks.
6. Continue from the first incomplete roadmap item.
7. After a major product or architecture decision, update this file in the same change.
8. Keep the project zero recurring cost unless the owner explicitly changes that rule.

Suggested resume prompt:

`Read PROJECT_CONTEXT.md and docs/FLOWCHART.md, inspect the current repository, then continue HOMIQ from the first incomplete roadmap item without changing locked decisions.`

## 2. Product identity

Name: HOMIQ

Type: Private homestay management app for the owner.

Primary purpose: Record and manage bookings that have already been received manually from WhatsApp or any other source, then track operations and money in one place.

HOMIQ is not:

- A public booking platform.
- A marketplace for guests.
- A guest social app.
- A payment gateway.
- A subscription SaaS product.
- Dependent on a server for basic daily use.

## 3. Locked requirements

These decisions are locked unless the owner explicitly changes them.

- App name is HOMIQ.
- Android first.
- Kotlin and Jetpack Compose.
- Owner only.
- Zero recurring operating cost is a core requirement.
- App must work offline for normal daily management.
- Bahasa Melayu and English.
- Manual booking entry is the primary workflow.
- Multiple homestay properties must be supported.
- Local data is the primary working copy.
- Account sign-in is optional.
- Local backup is required.
- Google Drive backup is required.
- Multi-device sync using the same account is optional but planned.
- Deposits must be tracked separately from revenue.
- The app must remain simple and fast.
- Guest installation is never required.

## 4. Main navigation

Five primary bottom navigation destinations:

1. Home
2. Calendar
3. Bookings
4. Money
5. More

A global add action provides the shell for:

- New booking
- Record payment
- Add expense
- Block date

Until the related data phases are implemented, quick-add actions intentionally show a development message instead of creating fake data.

## 5. Core feature scope

### Home

The owner should immediately see:

- Revenue for selected period
- Expenses
- Net income
- Occupancy
- Today's check-ins
- Today's check-outs
- Outstanding balances
- Upcoming bookings
- Items needing attention

### Properties

Support one or many homestays.

Planned property fields:

- id
- name
- optional address
- optional notes
- default nightly rate
- active status
- createdAt
- updatedAt

### Bookings

Fast manual entry is critical.

Planned booking fields:

- id
- propertyId
- guestName
- guestPhone
- checkInDate
- checkOutDate
- source
- totalAmount
- bookingStatus
- notes
- createdAt
- updatedAt
- sync metadata when sync is enabled

Booking sources should include:

- WhatsApp
- Airbnb
- Booking.com
- Facebook
- TikTok
- Repeat Guest
- Walk-in
- Other

### Calendar

Calendar must show booked, available, and blocked dates clearly.

For multiple properties, the owner must be able to understand availability without opening each property separately.

Double booking prevention is required.

### Payments

Payments are records only. HOMIQ does not process money.

A booking can have multiple payment entries.

Planned payment fields:

- id
- bookingId
- amount
- paymentDate
- method
- notes
- createdAt
- updatedAt

The app calculates:

- Total booking value
- Total paid
- Outstanding balance

### Deposits

Security deposit is not revenue.

Deposit state should support:

- Not required
- Pending
- Received
- Partially returned
- Returned
- Retained

### Expenses

Planned categories:

- Cleaning
- Electricity
- Water
- Internet
- Supplies
- Maintenance
- Laundry
- Platform fee
- Other

Expenses may optionally be attached to a property.

### Money and reports

Required calculations:

- Revenue
- Expenses
- Net income
- Occupancy percentage
- Average booking value
- Revenue per property
- Expenses per property
- Booking source breakdown
- Monthly performance
- Yearly performance

Financial formulas must be documented and tested before reports are considered complete.

## 6. Language

Supported languages:

- Bahasa Melayu
- English

Runtime language selection is implemented in More using Android per-app locales.

Current behaviour:

- User can select English.
- User can select Bahasa Melayu.
- AndroidX AppCompat handles backward-compatible locale switching.
- Locale choice is auto-stored on Android 12 and lower.
- `locales_config.xml` exposes English and Malay as supported app languages.
- User-entered data is never translated.

A dedicated first-launch language onboarding screen can be added later if it improves the final onboarding flow. It is not required for the Phase 1 shell.

## 7. Visual direction

Phase 1 establishes the HOMIQ visual foundation.

Direction:

- Modern, calm, clean and owner-focused.
- Information first, without looking like enterprise property software.
- Primary brand family: deep homestay green with soft mint surfaces.
- Neutral off-white canvas in light mode.
- Full dark mode support.
- Rounded Material 3 cards with low elevation.
- Financial cards prioritise legibility over decoration.
- No neon styling.
- No guest marketplace styling.
- No unnecessary imagery in operational screens.

The theme is implemented through `ui/theme`.

## 8. Local first architecture

Daily HOMIQ usage must not depend on internet access.

Target data flow:

`UI -> ViewModel -> Repository -> Local database`

When optional sync is enabled:

`Local database <-> Sync engine <-> Cloud copy`

Local data remains usable when:

- Internet is unavailable.
- Cloud sync is unavailable.
- Google Drive is unavailable.
- User chooses not to create an account.

Planned local database: Room or the current recommended Android local persistence layer after compatibility verification at implementation time.

Do not make cloud storage the only source for bookings.

## 9. Account strategy

Account is optional.

### Local only

- No sign-in required.
- All features except cloud backup and cross-device sync should remain usable.
- Local backup remains available.

### Signed in

- Account identity.
- Google Drive backup.
- Restore from Google Drive.
- Optional multi-device sync.
- Sync status visible to owner.

Google account sign-in is the preferred route for Drive-linked backup because a Drive backup necessarily belongs to a Google account.

Any cloud provider must be evaluated against the zero recurring cost requirement before implementation.

## 10. Backup strategy

Backup and sync are separate features.

### Local backup

Required actions:

- Export backup file.
- Import backup file.
- Validate backup version before restore.
- Prevent accidental destructive restore.
- Preserve all business records and app settings required for recovery.

### Google Drive backup

Required actions:

- Backup now.
- Show last successful backup.
- Restore from Drive.
- Handle no internet.
- Handle revoked Google permission.
- Never silently overwrite a newer backup without conflict checks.

Google Drive backup is a disaster recovery mechanism, not the live sync engine.

## 11. Multi-device sync

Goal:

Phone A and Phone B signed into the same HOMIQ account can eventually share current data.

Required behaviour:

- Changes save locally first.
- Pending local changes queue while offline.
- Changes sync when internet returns.
- Visible sync state such as Synced or Changes waiting.
- Conflict handling is explicit.
- Deletions must sync safely.
- Sync must never create duplicate bookings or payments.

Initial conflict strategy to evaluate:

- Stable UUID per record.
- updatedAt timestamp.
- revision or version number.
- soft delete tombstone for synced deletion.
- deterministic conflict rules.
- manual conflict UI only where automatic resolution is unsafe.

Cloud implementation is not locked yet. It must be chosen only after verifying quota, cost, Android support, offline behaviour, and long-term maintenance.

## 12. Security and privacy

Planned:

- App lock using device biometrics or PIN.
- Do not store passwords in plain text.
- Do not commit credentials or API secrets.
- Minimise guest personal data.
- Backups must not expose data unnecessarily.
- Cloud access should be scoped to the signed-in owner.

The manifest disables Android automatic app backup because HOMIQ will implement explicit controlled backup and restore.

## 13. Architecture

Start simple. Avoid premature over-engineering.

Package root:

`com.homiq.app`

Current UI structure:

- `ui/HomiqApp.kt`
- `ui/components`
- `ui/screens`
- `ui/theme`

Later packages may include:

- data.local
- data.model
- data.repository
- data.backup
- data.sync
- domain
- ui.home
- ui.calendar
- ui.bookings
- ui.money
- ui.more

Preferred Android pattern:

- Single activity
- Jetpack Compose
- Unidirectional UI state
- ViewModel per feature where useful
- Repository boundary between UI and persistence
- Coroutines and Flow
- Local first persistence
- Dependency injection only when complexity justifies it

## 14. Development roadmap

### Phase 0: Foundation

- [x] Lock product name HOMIQ
- [x] Lock owner-only concept
- [x] Lock bilingual requirement
- [x] Lock local first direction
- [x] Lock local and Google Drive backup requirements
- [x] Lock optional multi-device sync direction
- [x] Create Android project scaffold
- [x] Create bilingual Android resource scaffold
- [x] Create repository context document
- [x] Create end-to-end flowchart
- [x] Confirm generated project builds in GitHub Actions

### Phase 1: Product shell

- [x] App theme and visual direction
- [x] Bottom navigation
- [x] Home shell
- [x] Calendar shell with current-month grid
- [x] Bookings shell
- [x] Money shell
- [x] More shell
- [x] Global quick-add sheet
- [x] Runtime language selection
- [x] Dark mode theme foundation
- [ ] Confirm Phase 1 files build successfully after repository upload

Phase 1 completion is considered final only after the uploaded files build successfully in the repository. If a compile correction is required, keep Phase 2 blocked until Phase 1 is green.

### Phase 2: Local data foundation

- [ ] Select and add local database
- [ ] Define entities and migrations
- [ ] Property repository
- [ ] Booking repository
- [ ] Payment repository
- [ ] Deposit repository or deposit model
- [ ] Expense repository
- [ ] Blocked dates
- [ ] Local data tests

### Phase 3: Properties and bookings

- [ ] Property management
- [ ] New booking form
- [ ] Booking validation
- [ ] Double booking prevention
- [ ] Booking details
- [ ] Edit booking
- [ ] Cancel booking
- [ ] Booking source tracking

### Phase 4: Calendar

- [ ] Monthly calendar connected to data
- [ ] Multi-property availability
- [ ] Booking colour/state rules
- [ ] Block date
- [ ] Tap date to create booking
- [ ] Tap booking to open details

### Phase 5: Payments and deposits

- [ ] Record payment
- [ ] Multiple payments per booking
- [ ] Paid and balance calculation
- [ ] Deposit receive
- [ ] Deposit return
- [ ] Deposit retain
- [ ] Payment history

### Phase 6: Expenses and money

- [ ] Expense entry
- [ ] Expense categories
- [ ] Revenue calculation
- [ ] Expense calculation
- [ ] Net income calculation
- [ ] Monthly summary
- [ ] Property breakdown

### Phase 7: Dashboard and reports

- [ ] Today dashboard connected to live data
- [ ] Check-ins and check-outs
- [ ] Occupancy formula
- [ ] Booking source analytics
- [ ] Monthly report
- [ ] Yearly report
- [ ] Export report if useful

### Phase 8: Backup and restore

- [ ] Backup schema and versioning
- [ ] Local export
- [ ] Local import
- [ ] Restore validation
- [ ] Google sign-in for Drive
- [ ] Google Drive backup
- [ ] Google Drive restore
- [ ] Backup status

### Phase 9: Optional multi-device sync

- [ ] Select free-cost-compatible sync backend
- [ ] Account data ownership rules
- [ ] Sync metadata
- [ ] Upload pending local changes
- [ ] Download remote changes
- [ ] Offline queue
- [ ] Conflict strategy
- [ ] Safe deletion sync
- [ ] Sync status UI
- [ ] Two-device testing

### Phase 10: Security and polish

- [ ] Biometric or PIN app lock
- [ ] Error states
- [ ] Empty states
- [ ] Accessibility
- [ ] Performance review
- [ ] Data integrity tests
- [ ] Backup recovery test
- [ ] Final BM and English copy review
- [ ] UI polish

### Phase 11: Release

- [ ] Versioning
- [ ] Release signing strategy
- [ ] Release build
- [ ] Fresh-install test
- [ ] Upgrade test
- [ ] Backup and restore test
- [ ] APK distribution for owner use
- [ ] Update repository context

## 15. Definition of done for V1

V1 is complete only when the owner can:

1. Install HOMIQ.
2. Choose BM or English.
3. Create at least one property.
4. Enter a manual booking quickly.
5. View bookings on a calendar.
6. Record partial and full payments.
7. Track deposits separately.
8. Add operating expenses.
9. See revenue, expenses, net income, and occupancy.
10. View booking source performance.
11. Use the core app offline.
12. Create and restore a local backup.
13. Optionally sign in and back up to Google Drive.
14. If sync is enabled, use the same data safely on two phones.
15. Lock the app with device security.
16. Recover data after reinstall or phone replacement using a valid backup.

## 16. Current state

Expected repository state after Phase 1 files are uploaded:

- Android project remains on compileSdk 36.
- HOMIQ opens into the five-tab product shell.
- Home shows zero-state business summary cards.
- Calendar renders the current month before database integration.
- Bookings, Money and More have polished zero-state shells.
- Global quick-add UI exists but is intentionally not wired to persistence yet.
- English and Bahasa Melayu can be changed at runtime.
- Light and dark HOMIQ themes are present.
- No business database is implemented yet.
- No account, Drive, or cloud sync code is implemented yet.
- Next development task after a green build is Phase 2: Local data foundation.

## 17. Change log

### 31 August 2026, Phase 1

- Established HOMIQ deep-green and soft-mint visual system.
- Added full five-tab product shell.
- Added Home zero-state dashboard.
- Added current-month Calendar shell.
- Added Bookings and Money zero states.
- Added More settings shell.
- Added global quick-add bottom sheet.
- Added English and Bahasa Melayu runtime language switching.
- Added AppCompat locale storage compatibility.
- Added light and dark theme foundations.

### 31 August 2026, Phase 0

- HOMIQ name locked.
- Owner-only manual homestay management concept locked.
- Zero recurring operating cost requirement locked.
- BM and English requirement locked.
- Local backup and Google Drive backup planned.
- Optional same-account multi-device sync planned.
- Android local-first architecture selected.
- Initial repository bootstrap created.
