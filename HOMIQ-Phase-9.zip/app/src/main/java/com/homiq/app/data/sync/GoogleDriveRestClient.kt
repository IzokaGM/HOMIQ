package com.homiq.app.data.sync

import java.net.URLEncoder
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class DriveSyncFile(
    val id: String,
    val name: String,
)

class GoogleDriveRestClient(
    private val client: OkHttpClient =
        OkHttpClient(),
) {
    fun listSyncFiles(
        accessToken: String,
    ): List<DriveSyncFile> {
        val query =
            "name contains '$FILE_PREFIX' and trashed = false"
        val url =
            "$DRIVE_API/files" +
                "?spaces=appDataFolder" +
                "&pageSize=100" +
                "&fields=files(id%2Cname)" +
                "&q=${
                    URLEncoder.encode(
                        query,
                        "UTF-8",
                    )
                }"

        val response =
            execute(
                Request.Builder()
                    .url(url)
                    .authorization(
                        accessToken,
                    )
                    .get()
                    .build(),
            )

        val files =
            JSONObject(response)
                .optJSONArray("files")
                ?: JSONArray()

        return List(files.length()) { index ->
            val item =
                files.getJSONObject(index)
            DriveSyncFile(
                id = item.getString("id"),
                name = item.getString("name"),
            )
        }.filter {
            it.name.startsWith(
                FILE_PREFIX,
            )
        }
    }

    fun download(
        fileId: String,
        accessToken: String,
    ): String =
        execute(
            Request.Builder()
                .url(
                    "$DRIVE_API/files/$fileId" +
                        "?alt=media",
                )
                .authorization(
                    accessToken,
                )
                .get()
                .build(),
        )

    fun create(
        fileName: String,
        content: String,
        accessToken: String,
    ) {
        val boundary =
            "homiq_${System.nanoTime()}"
        val metadata =
            JSONObject()
                .put("name", fileName)
                .put(
                    "parents",
                    JSONArray().put(
                        "appDataFolder",
                    ),
                )
                .toString()

        val bodyText = buildString {
            append("--")
            append(boundary)
            append("\r\n")
            append(
                "Content-Type: application/json; charset=UTF-8\r\n\r\n",
            )
            append(metadata)
            append("\r\n--")
            append(boundary)
            append("\r\n")
            append(
                "Content-Type: application/json; charset=UTF-8\r\n\r\n",
            )
            append(content)
            append("\r\n--")
            append(boundary)
            append("--\r\n")
        }

        val body =
            bodyText.toRequestBody(
                (
                    "multipart/related; " +
                        "boundary=$boundary"
                    ).toMediaType(),
            )

        execute(
            Request.Builder()
                .url(
                    "$DRIVE_UPLOAD/files" +
                        "?uploadType=multipart" +
                        "&fields=id%2Cname",
                )
                .authorization(
                    accessToken,
                )
                .post(body)
                .build(),
        )
    }

    fun update(
        fileId: String,
        content: String,
        accessToken: String,
    ) {
        val body =
            content.toRequestBody(
                JSON_MEDIA_TYPE,
            )

        execute(
            Request.Builder()
                .url(
                    "$DRIVE_UPLOAD/files/$fileId" +
                        "?uploadType=media" +
                        "&fields=id%2Cname",
                )
                .authorization(
                    accessToken,
                )
                .patch(body)
                .build(),
        )
    }

    private fun execute(
        request: Request,
    ): String =
        client.newCall(request)
            .execute()
            .use { response ->
                val responseBody =
                    response.body.string()

                if (!response.isSuccessful) {
                    throw DriveHttpException(
                        statusCode =
                            response.code,
                        responseBody =
                            responseBody,
                    )
                }

                responseBody
            }

    private fun Request.Builder.authorization(
        accessToken: String,
    ): Request.Builder =
        header(
            "Authorization",
            "Bearer $accessToken",
        ).header(
            "Accept",
            "application/json",
        )

    companion object {
        const val FILE_PREFIX =
            "homiq-sync-device-"

        private const val DRIVE_API =
            "https://www.googleapis.com/drive/v3"

        private const val DRIVE_UPLOAD =
            "https://www.googleapis.com/upload/drive/v3"

        private val JSON_MEDIA_TYPE =
            "application/json; charset=UTF-8"
                .toMediaType()
    }
}

class DriveHttpException(
    val statusCode: Int,
    val responseBody: String,
) : RuntimeException(
    "Drive HTTP $statusCode",
)
